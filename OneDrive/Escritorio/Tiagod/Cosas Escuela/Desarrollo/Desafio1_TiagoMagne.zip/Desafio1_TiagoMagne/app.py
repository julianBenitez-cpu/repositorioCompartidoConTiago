# Narcissa´s Garden

jardin = []

def AñadirPlanta():
    nombre = input("Ingrese el nombre de la planta: ")
    color = input("Ingrese el color de la planta: ")
    poder = input("Ingrese el poder especial de la planta: ")
    cantidad = int(input("Ingrese la cantidad de esta planta: "))
    planta = {"nombre": nombre, "color": color, "poder": poder, "cantidad": cantidad}
    jardin.append(planta)
    print("Su planta ha sido registrada existosamente\n")

def ClasificarPorPoder():
    poderes = {}
    for planta in jardin:
        poder = planta["poder"]
        if poder not in poderes:
            poderes[poder] = []
        poderes[poder].append(planta)
    
    print("\nPlantas clasificadas por poder:")
    for poder, plantas in poderes.items():
        print(f"\nPoder: {poder}")
        for planta in plantas:
            print(f"  - {planta['nombre']} (Color: {planta['color']}, Cantidad: {planta['cantidad']})")
    print()

def CalcularColoresUnicos():
    colores = {planta["color"] for planta in jardin}
    print(f"\nCantidad de colores unicos en el jardin: {len(colores)}\n")

def GestionarCantidad():
    print("\nLista de plantas:")
    for i, planta in enumerate(jardin):
        print(f"{i + 1}. {planta['nombre']} (Cantidad: {planta['cantidad']})")
    
    indice = int(input("\nSeleccione el numero de planta que desea gestionar: ")) - 1
    if 0 <= indice < len(jardin):
        nueva_cantidad = int(input(f"Ingrese la nueva cantidad para {jardin[indice]['nombre']}: "))
        jardin[indice]["cantidad"] = nueva_cantidad
        print(f"La cantidad de {jardin[indice]['nombre']} ha sido actualizada a {nueva_cantidad}.\n")
    else:
        print("Número inválido.\n")

def menu():
    while True:
        print("1. Añadir planta mágica")
        print("2. Mostrar plantas clasificadas por tipo de poder")
        print("3. Calcular cantidad de colores únicos")
        print("4. Gestionar cantidad de plantas")
        print("5. Salir")
        opcion = input("Elige una opción: ")
        
        if opcion == "1":
            AñadirPlanta()
        elif opcion == "2":
            ClasificarPorPoder()
        elif opcion == "3":
            CalcularColoresUnicos()
        elif opcion == "4":
            GestionarCantidad()
        elif opcion == "5":
            print("Nos vemos")
            break
        else:
            print("Este numero no entra dentro de las opciones.\n")

menu()